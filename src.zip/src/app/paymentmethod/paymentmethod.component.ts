import { Component, OnInit } from '@angular/core';
import { payment_method_list } from './paymentlist';

@Component({
  selector: 'app-paymentmethod',
  templateUrl: './paymentmethod.component.html',
  styleUrls: ['./paymentmethod.component.css']
})
export class PaymentmethodComponent implements OnInit {
  paymentmethodlist=payment_method_list
  gofor:string=""
  name:string=""
   service_selected=""

  constructor() { }

  ngOnInit(): void {
  }
    onSelect(value:string){
      this.gofor=value
  }
}