import { paymentlistlist } from "./payment_list"

export const payment_method_list:paymentlistlist[]=[
   
    {
        name:'Credit Card'
    },
    {
       name:'Net Banking'
    },
    {
        name:'Cash on Delivery'
    },
    {
        name:'UPI'
    }
]