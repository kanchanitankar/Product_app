export interface paymentlistlist{
    name:string
}