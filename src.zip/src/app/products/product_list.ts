export interface productlistlist{
    name:string
}