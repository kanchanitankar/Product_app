import { productlistlist } from "./product_list"

export const product_method_list:productlistlist[]=[
   
    {
        name:'redmi5A'
    },
    {
       name:'vivo'
    },
    {
        name:'samsung'
    },
    {
        name:'nokia'
    }
]