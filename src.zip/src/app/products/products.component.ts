import { Component, OnInit } from '@angular/core';
import { product_method_list } from './productlist';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  productmethodlist=product_method_list
  gofor:string=""
  name:string=""
   service_selected=""
     myimage:string="assets/images/redmi5a.PNG";
     myimage2:string="assets/images/vivo.PNG";
     myimage3:string="assets/images/samsung.PNG";
     myimage4:string="assets/images/nokia.PNG";

  constructor() { }

  ngOnInit(): void {
  }
    onSelect(value:string){
      this.gofor=value
  }
}