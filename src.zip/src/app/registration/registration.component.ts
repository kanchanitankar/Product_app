import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  message:any
  userdetails:{
    'username':'',
    'password':''
  }={'username':'',
  'password':''
    
  }
  onSubmit(){
    console.log(this.userdetails)
  }
  validated:boolean=false
    constructor(private http:HttpClient) {
      http.get("http://localhost:8082/",{responseType:'json'}).subscribe(observer=>{
        this.message=observer
      })
     }
  
     token:{'token':""}={'token':''}
  
     register()
     {
  
       this.http.post("http://localhost:8082/registration",{username:'peter',password:'123'},{responseType:'json'}).subscribe(observer=>{
         this.token=observer as {'token':''}
       })
     }
     login()
     {
      this.http.post("http://localhost:8082/login",this.token ,{responseType:'json'}).subscribe(observer=>{
        console.log(observer)
      if(observer)
      {
        console.log('authenticated')
        this.validated=true
        
      }
     
    })
    
  }
     
  

  ngOnInit(): void {
  }

}
