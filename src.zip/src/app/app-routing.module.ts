import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaymentmethodComponent } from './paymentmethod/paymentmethod.component';
import { RegistrationComponent } from './registration/registration.component';
import { ProductsComponent } from './products/products.component';

const routes: Routes = [
  {
    path:"products",component:ProductsComponent
  },
  {
    path:"registration",component:RegistrationComponent
  },
  {
    path:"paymentmethod",component:PaymentmethodComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
